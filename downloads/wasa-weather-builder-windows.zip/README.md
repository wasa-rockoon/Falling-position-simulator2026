﻿# WASA Weather Builder for Windows

## Requirements

- Windows 11
- Node.js 20.3 or later
- Docker Desktop (WSL2 backend)

## Usage

1. Extract this ZIP.
2. Double-click start-weather-builder.bat.
3. Choose the date, location, duration, and region in the opened page.
4. Review the suggested range and start the build.
5. Import the generated .wasawx file into the simulator.

Weather Builder downloads a regional subset of NOAA GFS. It does not call a flight prediction API.
